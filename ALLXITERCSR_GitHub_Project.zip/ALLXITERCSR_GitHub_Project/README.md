# ALLXITERCSR — APK reverse-engineering/edit project

Repository starter to inspect and rebuild the supplied APK with the ALLXITERCSR theme image. It is **not** the original Android Studio source project: the supplied APK contains compiled DEX and native `.so` libraries, so the original Java/Kotlin/Gradle source cannot be recovered exactly.

## Contents

- `original/source.apk` — original APK provided for this edit.
- `branding/ALLXITERCSR_theme.jpg` — user-provided theme artwork.
- `scripts/prepare_and_build.sh` — decodes APK with Apktool, replaces `res/drawable/lv_team.png`, updates matching visible string resources/manifest literals, rebuilds, and signs with a temporary debug key.
- `.github/workflows/build-apk.yml` — GitHub Actions workflow. Run it from **Actions → Build ALLXITERCSR APK → Run workflow**; download the `ALLXITERCSR-debug-apk` artifact when complete.

## Run locally (Ubuntu/Linux)

Install Java, Python 3 + Pillow, Apktool, and Android SDK build-tools (`apksigner`). Then run:

```bash
./scripts/prepare_and_build.sh
```

Output: `build/output/ALLXITERCSR-debug-signed.apk`.

## Important limitations

1. A decoded/rebuilt APK is not the same as an original Android Studio project. This repository is a reproducible reverse-engineering workflow, not recovered original source code.
2. The script replaces the theme resource and string/manifest literals it can identify. Names hardcoded in DEX bytecode, encrypted/configured remotely, or inside `libMahirProxy.so` may remain unchanged. Inspect with JADX and test the app after building.
3. The output uses a temporary debug signing key. It will not update/install over the original app if its signing certificate differs. For release builds, create and protect your own keystore; never commit it to GitHub.
4. Only modify and redistribute APKs you own or are authorized to modify. Keep the original package/application ID unless you understand the consequences.
