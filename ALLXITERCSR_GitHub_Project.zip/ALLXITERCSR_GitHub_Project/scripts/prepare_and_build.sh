#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APKTOOL_BIN="${APKTOOL_BIN:-apktool}"
APKSIGNER_BIN="${APKSIGNER_BIN:-apksigner}"
INPUT="$ROOT/original/source.apk"
WORK="$ROOT/build/work"
OUT="$ROOT/build/output"

command -v "$APKTOOL_BIN" >/dev/null || { echo 'apktool tidak ditemukan. Instal apktool terlebih dahulu.' >&2; exit 1; }
command -v "$APKSIGNER_BIN" >/dev/null || { echo 'apksigner tidak ditemukan. Instal Android build-tools.' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'python3 tidak ditemukan.' >&2; exit 1; }

rm -rf "$WORK" "$OUT"
mkdir -p "$WORK" "$OUT"
"$APKTOOL_BIN" d -f "$INPUT" -o "$WORK/decoded"

# Ganti gambar tema yang dipakai APK jika resource tersebut ditemukan.
python3 - "$ROOT" "$WORK/decoded" <<'PY'
from pathlib import Path
from PIL import Image
import sys
root, decoded = Path(sys.argv[1]), Path(sys.argv[2])
source = root / 'branding' / 'ALLXITERCSR_theme.jpg'
# APK memakai nama lv_team.png; simpan dalam format PNG yang benar.
with Image.open(source) as im:
    im.convert('RGB').save(decoded / 'res' / 'drawable' / 'lv_team.png', format='PNG')

# Ubah string resource yang jelas berisi nama lama, tanpa mengubah package ID.
for f in (decoded / 'res').glob('values*/strings.xml'):
    try: s = f.read_text(encoding='utf-8')
    except (UnicodeDecodeError, OSError): continue
    for old in ('AIZARO PROXY', 'AIZARO CHATS', 'AIZARO'):
        s = s.replace(old, 'ALLXITERCSR')
    f.write_text(s, encoding='utf-8')

# Jika label aplikasi berupa teks langsung di manifest, ubah juga.
manifest = decoded / 'AndroidManifest.xml'
if manifest.exists():
    s = manifest.read_text(encoding='utf-8')
    for old in ('AIZARO PROXY', 'AIZARO CHATS', 'AIZARO'):
        s = s.replace(old, 'ALLXITERCSR')
    manifest.write_text(s, encoding='utf-8')
PY

"$APKTOOL_BIN" b "$WORK/decoded" -o "$OUT/ALLXITERCSR-unsigned.apk"

# Buat debug key hanya untuk build percobaan/CI. Untuk distribusi, gunakan key milik sendiri.
KEYSTORE="$WORK/github-debug.keystore"
if [[ ! -f "$KEYSTORE" ]]; then
  if command -v keytool >/dev/null; then
    keytool -genkeypair -v -keystore "$KEYSTORE" -storepass android -alias androiddebugkey \
      -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
      -dname 'CN=Android Debug,O=Android,C=US' >/dev/null 2>&1
  else
    echo 'keytool tidak ditemukan; tidak dapat membuat debug key.' >&2; exit 1
  fi
fi
"$APKSIGNER_BIN" sign --ks "$KEYSTORE" --ks-pass pass:android --key-pass pass:android \
  --out "$OUT/ALLXITERCSR-debug-signed.apk" "$OUT/ALLXITERCSR-unsigned.apk"
"$APKSIGNER_BIN" verify "$OUT/ALLXITERCSR-debug-signed.apk"
echo "Selesai: $OUT/ALLXITERCSR-debug-signed.apk"
echo 'Catatan: nama yang tertanam dalam DEX/native library mungkin perlu diubah manual; cek hasil di perangkat.'
