ALLXITERCSR Android UI prototype
================================
This is an Android Studio source project, not a compiled APK.
It provides a red/black ALLXITERCSR panel with interactive demo toggles and sensitivity sliders.
It does NOT modify Free Fire and does not implement auto-headshot, aimbot, ESP, or anti-ban functionality.

Build:
1. Open this folder in Android Studio.
2. Allow Gradle sync (requires internet and Android SDK).
3. Select Build > Build APK(s).
4. APK output is typically app/build/outputs/apk/debug/app-debug.apk.

Package: com.allxitercsr.panel
App label: ALLXITERCSR

OPTION: Build in GitHub Actions (no PC needed)
==============================================
1. Create/sign in to a GitHub account in your browser.
2. Create a new repository named ALLXITERCSR (public or private).
3. Extract this ZIP on a computer, or upload the extracted project files/folders to the repository.
   Include the hidden .github/workflows/build-apk.yml file.
4. Open the repository's Actions tab.
5. Select "Build ALLXITERCSR APK" and press "Run workflow" (or push/commit files to main).
6. When the run succeeds, open the run, scroll to Artifacts, and download ALLXITERCSR-debug-apk.
7. Extract the downloaded artifact ZIP; inside is app-debug.apk.

This cloud workflow builds the UI demo only; it does not implement game cheats.
